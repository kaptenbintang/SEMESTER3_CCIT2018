/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pojo;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author kaptenbintang
 */
@ManagedBean(name = "login2",eager = true)
@RequestScoped

public class Login {
     public String username,password,message;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    /**
     * Creates a new instance of login
     */
    public String loginAdmin() {
        if(username.equals("admin@gmail.com")&&password.equals("admin"))
        {
            message = "Login Success As";
            return "admin_index";
        }
        
        else
    
        {
        message = "Login Failed";
        return "login";
    }
    }
    public String loginUser() {
        if(username.equals("user@gmail.com")&&password.equals("user"))
        {
            message = "Login Success As";
            return "order";
        }
        
        else
    
        {
        message = "Login Failed";
        return "login";
    }
    }
}
