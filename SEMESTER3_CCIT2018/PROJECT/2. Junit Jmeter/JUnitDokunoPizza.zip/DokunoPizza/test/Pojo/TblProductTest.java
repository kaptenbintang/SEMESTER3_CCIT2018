/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pojo;

import java.util.ArrayList;
import java.util.List;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kaptenbintang
 */
public class TblProductTest {
    
    public TblProductTest() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    @Test
    public void idPizza(){
    System.out.println("ID Pizza");
    TblProduct tbl = new TblProduct();
    String idPizza = tbl.idPizza("001");
    String exp = "001";
    if (!idPizza.equals(exp)){
        System.out.println("nilai tidak sama dengan ekspetasi");
    }else{
        System.out.println("Id Pizza = " + idPizza);
    }
    assertEquals(exp, idPizza);
    assertThat(idPizza, startsWith("0"));
    }
    
    public List<String> name;
    @Test
    public void pizzaName()
    {
        System.out.println("pizzaName");
        TblProduct tbl = new TblProduct();
        name = new ArrayList<String>();
        name.add("Veggie's Lover");
        name.add("Cheese Mani");
        name.add("Extravaganza");
        name.add("Meatzza");
        assertThat(name,hasItem("fkewbfkj"));
    }
    
    @Test
    public void testSubmit()
    {
        System.out.println("Submit");
        
        int stock = 1000, take = 10;
        TblProduct tbl = new TblProduct();
        int stockExp = 1000;
        int takeExp = 11;
        
        String expResult = tbl.submit(stockExp, takeExp);
        String result = tbl.submit(stock, take);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void price()
    {
        System.out.println("price");
        TblProduct tbl = new TblProduct();
        String price = tbl.price("Rp.20000");
        assertThat(price, startsWith("Rp."));
        assertThat(price,is(notNullValue()));
    }

}
