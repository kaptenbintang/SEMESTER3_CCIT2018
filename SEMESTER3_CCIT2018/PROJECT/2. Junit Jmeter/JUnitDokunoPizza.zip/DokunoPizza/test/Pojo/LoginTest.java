/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pojo;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kaptenbintang
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void loginAdmin() {
        System.out.println("Login Admin");
        Login lg = new Login();
        String email = ("admin@gmail.com");
        String password = ("admin");
        assertThat(email,containsString("@"));
        assertThat(email, endsWith(".com"));
        assertThat(email,password,is(notNullValue()));
        
    }
    @Test
    public void loginUser() {
        System.out.println("Login User");
        Login lg = new Login();
        String email = ("user@gmail.com");
        String password = ("user");
        assertThat(email,containsString("@"));
        assertThat(email, endsWith(".com"));
        assertThat(email,password,is(notNullValue()));
        
    }
    
    
}
