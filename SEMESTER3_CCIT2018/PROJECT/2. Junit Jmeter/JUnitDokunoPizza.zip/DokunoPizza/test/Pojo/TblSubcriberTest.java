/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pojo;

import java.util.List;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.startsWith;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kaptenbintang
 */
public class TblSubcriberTest {
    
    public TblSubcriberTest() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void idSubcriber(){
    System.out.println("Id Subcriber");
    TblSubcriber tbl = new TblSubcriber();
    String Subcriber = tbl.idSubcriber("001");
    String exp = "001";
    if (!Subcriber.equals(exp)){
        System.out.println("nilai tidak sama dengan ekspetasi");
    }else{
        System.out.println("Id Subcriber = " + Subcriber);
    }
    assertEquals(exp, Subcriber);
    assertThat(Subcriber, startsWith("0"));
    }
    
    @Test
    public void email(){
    System.out.println("email");
    TblSubcriber tbl = new TblSubcriber();
    String email = tbl.email("user@gmail.com");
    assertThat(email,allOf(containsString("@"),endsWith(".com")));
    }
    
    @Test
    public void phoneNumber(){
    System.out.println("phoneNumber");
    TblSubcriber tbl = new TblSubcriber();
    String phoneNumber = tbl.phoneNumber("081232183");
    assertThat(phoneNumber,is(notNullValue()));
    }
    
    
}
